<?php

namespace App\Services;

use App\Models\Activo;
use Illuminate\Support\Facades\Storage;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class QrService
{
    public function generarYGuardar(Activo $activo): string
{
    $carpeta  = "qrcodes/{$activo->empresa_id}";
    $archivo  = "{$carpeta}/{$activo->qr_token}.svg"; // ← extensión svg

    // Generar SVG del QR
    $imagen = QrCode::format('svg')
                    ->size(300)
                    ->margin(2)
                    ->generate($activo->urlPublica());

    Storage::disk('public')->put($archivo, $imagen);

    // Guardar ruta en el activo
    $activo->update(['qr_image' => $archivo]);

    return $archivo;
}

    public function urlQr(Activo $activo): ?string
    {
        if (! $activo->qr_image) return null;

        $path = 'storage/' . $activo->qr_image;

        // Si la petición actual es segura o la URL de la app configura HTTPS,
        // usar secure_asset; en otros casos usar asset() para evitar forzar HTTPS en local.
        $appUrl = config('app.url', '');
        $isSecureRequest = null;
        try {
            $isSecureRequest = request()?->isSecure();
        } catch (\Throwable $e) {
            $isSecureRequest = false;
        }

        if ($isSecureRequest || (is_string($appUrl) && str_starts_with($appUrl, 'https'))) {
            return secure_asset($path);
        }

        return asset($path);
    }
}